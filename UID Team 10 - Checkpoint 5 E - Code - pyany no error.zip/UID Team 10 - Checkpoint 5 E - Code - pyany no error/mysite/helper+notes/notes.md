1. create route in `flask_app.py`
2. replace `href` and `src`